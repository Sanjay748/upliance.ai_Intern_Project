```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

```


```python
# Load the datasets
file_path = r"C:\Users\LENOVO\Downloads\Data Analyst Intern Assignment - Excel.xlsx"

user_details = pd.read_excel(file_path, sheet_name="UserDetails.csv")
cooking_sessions = pd.read_excel(file_path, sheet_name="CookingSessions.csv")
order_details = pd.read_excel(file_path, sheet_name="OrderDetails.csv")

```


```python
# Preview the first few rows of each dataset
print("User Details:")
print(user_details.head())

print("\nCooking Sessions:")
print(cooking_sessions.head())

print("\nOrder Details:")
print(order_details.head())

```

    User Details:
      User ID      User Name  Age       Location Registration Date         Phone  \
    0    U001  Alice Johnson   28       New York        2023-01-15  123-456-7890   
    1    U002      Bob Smith   35    Los Angeles        2023-02-20  987-654-3210   
    2    U003    Charlie Lee   42        Chicago        2023-03-10  555-123-4567   
    3    U004    David Brown   27  San Francisco        2023-04-05  444-333-2222   
    4    U005     Emma White   30        Seattle        2023-05-22  777-888-9999   
    
                   Email Favorite Meal  Total Orders  
    0    alice@email.com        Dinner            12  
    1      bob@email.com         Lunch             8  
    2  charlie@email.com     Breakfast            15  
    3    david@email.com        Dinner            10  
    4     emma@email.com         Lunch             9  
    
    Cooking Sessions:
      Session ID User ID        Dish Name  Meal Type       Session Start  \
    0       S001    U001        Spaghetti     Dinner 2024-12-01 19:00:00   
    1       S002    U002     Caesar Salad      Lunch 2024-12-01 12:00:00   
    2       S003    U003  Grilled Chicken     Dinner 2024-12-02 19:30:00   
    3       S004    U001         Pancakes  Breakfast 2024-12-02 07:30:00   
    4       S005    U004     Caesar Salad      Lunch 2024-12-03 13:00:00   
    
              Session End  Duration (mins)  Session Rating  
    0 2024-12-01 19:30:00               30             4.5  
    1 2024-12-01 12:20:00               20             4.0  
    2 2024-12-02 20:10:00               40             4.8  
    3 2024-12-02 08:00:00               30             4.2  
    4 2024-12-03 13:15:00               15             4.7  
    
    Order Details:
       Order ID User ID Order Date  Meal Type        Dish Name Order Status  \
    0      1001    U001 2024-12-01     Dinner        Spaghetti    Completed   
    1      1002    U002 2024-12-01      Lunch     Caesar Salad    Completed   
    2      1003    U003 2024-12-02     Dinner  Grilled Chicken     Canceled   
    3      1004    U001 2024-12-02  Breakfast         Pancakes    Completed   
    4      1005    U004 2024-12-03      Lunch     Caesar Salad    Completed   
    
       Amount (USD) Time of Day  Rating Session ID  
    0          15.0       Night     5.0       S001  
    1          10.0         Day     4.0       S002  
    2          12.5       Night     NaN       S003  
    3           8.0     Morning     4.0       S004  
    4           9.0         Day     4.0       S005  
    


```python
# Check the basic info of each dataset
print("User Details Info:")
print(user_details.info())

print("\nCooking Sessions Info:")
print(cooking_sessions.info())

print("\nOrder Details Info:")
print(order_details.info())

```

    User Details Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10 entries, 0 to 9
    Data columns (total 9 columns):
     #   Column             Non-Null Count  Dtype         
    ---  ------             --------------  -----         
     0   User ID            10 non-null     object        
     1   User Name          10 non-null     object        
     2   Age                10 non-null     int64         
     3   Location           10 non-null     object        
     4   Registration Date  10 non-null     datetime64[ns]
     5   Phone              10 non-null     object        
     6   Email              10 non-null     object        
     7   Favorite Meal      10 non-null     object        
     8   Total Orders       10 non-null     int64         
    dtypes: datetime64[ns](1), int64(2), object(6)
    memory usage: 852.0+ bytes
    None
    
    Cooking Sessions Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 16 entries, 0 to 15
    Data columns (total 8 columns):
     #   Column           Non-Null Count  Dtype         
    ---  ------           --------------  -----         
     0   Session ID       16 non-null     object        
     1   User ID          16 non-null     object        
     2   Dish Name        16 non-null     object        
     3   Meal Type        16 non-null     object        
     4   Session Start    16 non-null     datetime64[ns]
     5   Session End      16 non-null     datetime64[ns]
     6   Duration (mins)  16 non-null     int64         
     7   Session Rating   16 non-null     float64       
    dtypes: datetime64[ns](2), float64(1), int64(1), object(4)
    memory usage: 1.1+ KB
    None
    
    Order Details Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 16 entries, 0 to 15
    Data columns (total 10 columns):
     #   Column        Non-Null Count  Dtype         
    ---  ------        --------------  -----         
     0   Order ID      16 non-null     int64         
     1   User ID       16 non-null     object        
     2   Order Date    16 non-null     datetime64[ns]
     3   Meal Type     16 non-null     object        
     4   Dish Name     16 non-null     object        
     5   Order Status  16 non-null     object        
     6   Amount (USD)  16 non-null     float64       
     7   Time of Day   16 non-null     object        
     8   Rating        14 non-null     float64       
     9   Session ID    16 non-null     object        
    dtypes: datetime64[ns](1), float64(2), int64(1), object(6)
    memory usage: 1.4+ KB
    None
    


```python
# Count missing values in each dataset
print("Missing Values in User Details:")
print(user_details.isnull().sum())

print("\nMissing Values in Cooking Sessions:")
print(cooking_sessions.isnull().sum())

print("\nMissing Values in Order Details:")
print(order_details.isnull().sum())

```

    Missing Values in User Details:
    User ID              0
    User Name            0
    Age                  0
    Location             0
    Registration Date    0
    Phone                0
    Email                0
    Favorite Meal        0
    Total Orders         0
    dtype: int64
    
    Missing Values in Cooking Sessions:
    Session ID         0
    User ID            0
    Dish Name          0
    Meal Type          0
    Session Start      0
    Session End        0
    Duration (mins)    0
    Session Rating     0
    dtype: int64
    
    Missing Values in Order Details:
    Order ID        0
    User ID         0
    Order Date      0
    Meal Type       0
    Dish Name       0
    Order Status    0
    Amount (USD)    0
    Time of Day     0
    Rating          2
    Session ID      0
    dtype: int64
    


```python
# Check for duplicates
print("Duplicate Rows in User Details:", user_details.duplicated().sum())
print("Duplicate Rows in Cooking Sessions:", cooking_sessions.duplicated().sum())
print("Duplicate Rows in Order Details:", order_details.duplicated().sum())

```

    Duplicate Rows in User Details: 0
    Duplicate Rows in Cooking Sessions: 0
    Duplicate Rows in Order Details: 0
    


```python
# Fill missing ratings in OrderDetails with the mean rating
order_details['Rating'].fillna(order_details['Rating'].mean(), inplace=True)

# Verify that there are no missing values left
print("Missing values in OrderDetails after filling ratings:")
print(order_details.isnull().sum())

```

    Missing values in OrderDetails after filling ratings:
    Order ID        0
    User ID         0
    Order Date      0
    Meal Type       0
    Dish Name       0
    Order Status    0
    Amount (USD)    0
    Time of Day     0
    Rating          0
    Session ID      0
    dtype: int64
    


```python
# Merge UserDetails with CookingSessions
user_cooking_data = pd.merge(user_details, cooking_sessions, on='User ID', how='inner')

# Merge the result with OrderDetails
final_data = pd.merge(user_cooking_data, order_details, on=['User ID', 'Session ID'], how='inner')

# Preview the merged dataset
print("Preview of the merged dataset:")
print(final_data.head())

# Check the structure of the merged dataset
print("\nStructure of the merged dataset:")
print(final_data.info())

```

    Preview of the merged dataset:
      User ID      User Name  Age     Location Registration Date         Phone  \
    0    U001  Alice Johnson   28     New York        2023-01-15  123-456-7890   
    1    U001  Alice Johnson   28     New York        2023-01-15  123-456-7890   
    2    U001  Alice Johnson   28     New York        2023-01-15  123-456-7890   
    3    U002      Bob Smith   35  Los Angeles        2023-02-20  987-654-3210   
    4    U002      Bob Smith   35  Los Angeles        2023-02-20  987-654-3210   
    
                 Email Favorite Meal  Total Orders Session ID  ...  \
    0  alice@email.com        Dinner            12       S001  ...   
    1  alice@email.com        Dinner            12       S004  ...   
    2  alice@email.com        Dinner            12       S009  ...   
    3    bob@email.com         Lunch             8       S002  ...   
    4    bob@email.com         Lunch             8       S006  ...   
    
      Duration (mins) Session Rating Order ID Order Date  Meal Type_y  \
    0              30            4.5     1001 2024-12-01       Dinner   
    1              30            4.2     1004 2024-12-02    Breakfast   
    2              40            4.9     1009 2024-12-05       Dinner   
    3              20            4.0     1002 2024-12-01        Lunch   
    4              30            4.3     1006 2024-12-03       Dinner   
    
           Dish Name_y  Order Status Amount (USD) Time of Day Rating  
    0        Spaghetti     Completed         15.0       Night    5.0  
    1         Pancakes     Completed          8.0     Morning    4.0  
    2  Grilled Chicken     Completed         12.0       Night    5.0  
    3     Caesar Salad     Completed         10.0         Day    4.0  
    4        Spaghetti     Completed         14.0       Night    4.0  
    
    [5 rows x 24 columns]
    
    Structure of the merged dataset:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 16 entries, 0 to 15
    Data columns (total 24 columns):
     #   Column             Non-Null Count  Dtype         
    ---  ------             --------------  -----         
     0   User ID            16 non-null     object        
     1   User Name          16 non-null     object        
     2   Age                16 non-null     int64         
     3   Location           16 non-null     object        
     4   Registration Date  16 non-null     datetime64[ns]
     5   Phone              16 non-null     object        
     6   Email              16 non-null     object        
     7   Favorite Meal      16 non-null     object        
     8   Total Orders       16 non-null     int64         
     9   Session ID         16 non-null     object        
     10  Dish Name_x        16 non-null     object        
     11  Meal Type_x        16 non-null     object        
     12  Session Start      16 non-null     datetime64[ns]
     13  Session End        16 non-null     datetime64[ns]
     14  Duration (mins)    16 non-null     int64         
     15  Session Rating     16 non-null     float64       
     16  Order ID           16 non-null     int64         
     17  Order Date         16 non-null     datetime64[ns]
     18  Meal Type_y        16 non-null     object        
     19  Dish Name_y        16 non-null     object        
     20  Order Status       16 non-null     object        
     21  Amount (USD)       16 non-null     float64       
     22  Time of Day        16 non-null     object        
     23  Rating             16 non-null     float64       
    dtypes: datetime64[ns](4), float64(3), int64(4), object(13)
    memory usage: 3.1+ KB
    None
    

# EDA

#### Analyze Popular Dishes and Meal Types


```python
# Most popular dishes
popular_dishes = final_data['Dish Name_x'].value_counts().head(10)
print("Top 10 Popular Dishes:")
print(popular_dishes)

# Most popular meal types
popular_meal_types = final_data['Meal Type_x'].value_counts()  # Use 'Meal Type_x' from CookingSessions
print("\nMost Popular Meal Types:")
print(popular_meal_types)
```

    Top 10 Popular Dishes:
    Dish Name_x
    Spaghetti          4
    Grilled Chicken    4
    Caesar Salad       3
    Pancakes           2
    Veggie Burger      2
    Oatmeal            1
    Name: count, dtype: int64
    
    Most Popular Meal Types:
    Meal Type_x
    Dinner       8
    Lunch        5
    Breakfast    3
    Name: count, dtype: int64
    

#### Analyze User Demographics


```python
# User count by location
user_location_counts = final_data['Location'].value_counts()
print("\nUser Counts by Location:")
print(user_location_counts)

# Create age groups for analysis
final_data['Age Group'] = pd.cut(final_data['Age'], bins=[0, 18, 30, 45, 60, 100], 
                                 labels=['<18', '18-30', '30-45', '45-60', '60+'])
age_group_analysis = final_data.groupby('Age Group')['Total Orders'].mean()
print("\nAverage Total Orders by Age Group:")
print(age_group_analysis)

```

    
    User Counts by Location:
    Location
    New York         3
    Los Angeles      3
    Chicago          3
    San Francisco    2
    Seattle          2
    Austin           1
    Boston           1
    Miami            1
    Name: count, dtype: int64
    
    Average Total Orders by Age Group:
    Age Group
    <18         NaN
    18-30    10.125
    30-45    11.000
    45-60       NaN
    60+         NaN
    Name: Total Orders, dtype: float64
    

    C:\Users\LENOVO\AppData\Local\Temp\ipykernel_10488\4041456903.py:9: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      age_group_analysis = final_data.groupby('Age Group')['Total Orders'].mean()
    

## Visualization

#### Popular Dishes


```python
# Bar plot for popular dishes
plt.figure(figsize=(10, 5))
sns.barplot(x=popular_dishes.values, y=popular_dishes.index, palette="viridis")
plt.title("Popularity")
plt.xlabel("Order Count")
plt.ylabel("Dish Name_x")
plt.show()
```


    
![png](output_15_0.png)
    


#### User Location Distribution


```python
user_location_counts.plot(kind='pie', autopct='%1.1f%%', figsize=(8, 8), colormap='Set3', legend=True, labeldistance=1.1)
plt.title("User Distribution by Location")
plt.ylabel("")  # Hide y-axis label for clarity

# Adjust the legend to be outside the pie chart but closer
plt.legend(loc='center left', bbox_to_anchor=(1.1, 0.5))

plt.show()

```


    
![png](output_17_0.png)
    


## Analyze Relationships


```python
# Correlation between session ratings and order ratings
correlation = final_data['Session Rating'].corr(final_data['Rating'])
print(f"\nCorrelation between Session Rating and Order Rating: {correlation:.2f}")

# Scatter plot
plt.figure(figsize=(8, 6))
sns.scatterplot(x='Session Rating', y='Rating', data=final_data, alpha=0.7)
plt.title("Session Rating vs. Order Rating")
plt.xlabel("Session Rating")
plt.ylabel("Order Rating")
plt.show()

```

    
    Correlation between Session Rating and Order Rating: 0.61
    


    
![png](output_19_1.png)
    


#### Order Trends by Time of Day


```python
# Orders by time of day
orders_by_time = final_data['Time of Day'].value_counts()
plt.figure(figsize=(10, 6))
sns.barplot(x=orders_by_time.index, y=orders_by_time.values, palette="coolwarm")
plt.title("Order Counts by Time of Day")
plt.xlabel("Time of Day")
plt.ylabel("Order Count")
plt.show()

```


    
![png](output_21_0.png)
    


## Findings

#### User Location Distribution
The pie chart highlights the geographic distribution of users across key cities:

Top Locations: Los Angeles Chicago and New York(18.8% each) are the largest user bases, followed by Seattle and San Francisco (12.5%).
Moderate Locations: Cities like Austin, Boston and and Miami account for 6.2% each.

Insights:
The majority of users are concentrated in large metropolitan areas.
Moderate presence in cities like Austin and Boston suggests room for growth.

#### Order Distribution by Food Items

The bar chart shows the popularity of menu items based on order counts:

Top Performers: Spaghetti is the most popular item, followed by Grilled Chicken.
Moderate Performer: Veggie Burger.
Low Performers: Caesar Salad, Pancakes, and Oatmeal.

Insights:
Spaghetti and Grilled Chicken are customer favorites, likely due to taste or familiarity.
Low-performing items may require adjustments in recipe, pricing, or promotion.
Recommendations:

Leverage Popular Items: Highlight Spaghetti and Grilled Chicken in marketing campaigns and create combo deals.
Revive Low Performers: Experiment with new flavors or promotional offers for items like Caesar Salad and Oatmeal.
Menu Optimization: Consider replacing persistently low-performing items with new offerings.

#### Order Trends by Time of Day

The bar chart reveals customer ordering behavior throughout the day:

Peak Period: Night (8 orders) sees the highest activity, suggesting strong customer preference for late-night dining.
Moderate Activity: Day (5 orders) reflects a steady, moderate level of engagement.
Low Activity: Morning (3 orders) has the least orders, indicating limited demand during early hours.

Insights:
Customers are most active at night, likely due to convenience or leisure time.
Morning orders are low, potentially due to fewer breakfast-specific offerings or lack of demand or maybe as the metropolitan areas are filled with workholic people who potentially skips breakfast and heads straight to brunch or lunch due to lack of time.

Recommendations:
Night-Time Focus: Offer exclusive late-night deals or extended hours to maximize revenue during peak periods.
Day-Time Promotions: Introduce lunch specials or discounts to drive more orders during the day.
Morning Strategy: Create a breakfast menu or offer morning discounts to attract early customers. Reduce the waiting time for the morning orders.


```python

```
